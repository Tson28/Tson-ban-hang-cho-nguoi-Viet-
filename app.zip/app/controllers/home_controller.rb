class HomeController < ApplicationController

  layout 'home'

  def index
  end

  def pricing

  end
end
