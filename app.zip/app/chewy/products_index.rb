class ProductsIndex < Chewy::Index
end