class UsersIndex < Chewy::Index
end