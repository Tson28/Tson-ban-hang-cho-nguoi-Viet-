module SaleHelper
end
