<template>
    <div class="input-group">
        <input type="text" class="form-control form-control-sm" placeholder="Tìm khách hàng (F4)" />
        <div class="input-group-append">
            <i class="fa fa-plus input-group-text"></i>
        </div>
    </div>
</template>

<script>
    export default {
        name: "SaleCustomer"
    }
</script>

<style scoped>

</style>