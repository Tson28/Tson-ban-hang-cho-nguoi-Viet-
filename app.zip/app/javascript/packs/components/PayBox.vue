<template>
    
</template>

<script>
    export default {
        name: "PayBox"
    }
</script>

<style scoped>

</style>