class StoreKind < ApplicationRecord
end
