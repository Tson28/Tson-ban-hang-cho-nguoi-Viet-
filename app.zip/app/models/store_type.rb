class StoreType < ApplicationRecord
  has_many :stores
end
