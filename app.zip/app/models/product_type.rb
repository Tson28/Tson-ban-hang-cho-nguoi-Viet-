class ProductType < ApplicationRecord
end
